str1= input("enter the string:")

times={}

print("occurances:\n")

for i in str1:
   
 if i in times:
       
 times[i]+= 1
       
 elif:
            
times[i]= 1
            
print(str1(times))

